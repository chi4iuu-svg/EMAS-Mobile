<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Emergency - EMAS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0093E9 0%, #002b4d 100%);
            min-height: 100vh;
            font-family: 'Inter', sans-serif;
            color: white;
            margin: 0;
            display: flex;
            flex-direction: column;
        }
        .main-card {
            background: linear-gradient(180deg, #0056b3 0%, #000814 100%);
            border-top-left-radius: 50px;
            border-top-right-radius: 50px;
            flex: 1;
            box-shadow: 0 -10px 25px rgba(0,0,0,0.3);
            padding: 30px 20px;
            overflow-y: auto;
            padding-bottom: 100px; /* Space for input bar */
        }
        /* User Bubble (Right) */
        .bubble-user {
            background: linear-gradient(to right, #4facfe 0%, #00f2fe 100%);
            color: white;
            border-radius: 25px 25px 5px 25px;
            padding: 12px 20px;
            max-width: 80%;
            align-self: flex-end;
            margin-bottom: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        /* Responder/Bot Bubble (Left) */
        .bubble-bot {
            background: #e5e7eb;
            color: #374151;
            border-radius: 25px 25px 25px 5px;
            padding: 12px 20px;
            max-width: 80%;
            align-self: flex-start;
            margin-bottom: 15px;
            position: relative;
        }
        .bot-avatar {
            width: 30px;
            height: 30px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #0056b3;
            font-size: 14px;
            position: absolute;
            left: -35px;
            bottom: 5px;
        }
        /* Input Bar Container */
        .input-container {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            width: 90%;
            max-width: 400px;
            background: white;
            border-radius: 50px;
            padding: 8px 15px;
            display: flex;
            align-items: center;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        }
        .message-input {
            border: none;
            outline: none;
            padding: 10px;
            flex: 1;
            color: #333;
            font-size: 14px;
        }
    </style>
</head>
<body>

    <div class="px-6 pt-10 pb-6 text-center">
        <div class="relative flex items-center justify-center">
            <a href="Main.php" class="absolute left-0 text-2xl hover:opacity-70">
                <i class="fa-solid fa-arrow-left"></i>
            </a>
            <h1 class="text-3xl font-bold">Report Emergency</h1>
        </div>
        <p class="text-lg opacity-90 mt-1">We're Here to Help</p>
    </div>

    <div class="main-card flex flex-col">
        
        <div class="bubble-user">
            Emergency Emergency
        </div>

        <div class="relative ml-10 flex flex-col items-start">
            <div class="bot-avatar">
                <i class="fa-solid fa-robot"></i>
            </div>
            <div class="bubble-bot">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            </div>
        </div>

        <div class="bubble-user">
            Lorem ipsum dolor sit amet, consectetur
        </div>

        <div class="relative ml-10 flex flex-col items-start">
            <div class="bot-avatar">
                <i class="fa-solid fa-robot"></i>
            </div>
            <div class="bubble-bot">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.
            </div>
        </div>

        <div class="bubble-user">
            Lorem ipsum dolor sit amet,
        </div>

    </div>

    <div class="input-container">
        <input type="text" placeholder="Write your message" class="message-input">
        <div class="flex gap-4 text-gray-400 text-xl px-2">
            <i class="fa-solid fa-paperclip cursor-pointer hover:text-blue-500"></i>
            <i class="fa-solid fa-microphone cursor-pointer hover:text-blue-500"></i>
            <i class="fa-solid fa-paper-plane text-blue-600 cursor-pointer"></i>
        </div>
    </div>

</body>
</html>